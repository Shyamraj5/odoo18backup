from odoo import fields, models, api
from odoo.exceptions import UserError
from odoo.tools.translate import _


class PosSession(models.Model):
    _inherit = 'pos.session'

    # Add new state to the selection
    POS_SESSION_STATE = [
        ('opening_control', 'Opening Control'),
        ('opened', 'In Progress'),
        ('to_review', 'To Review'),  # Custom state
        ('closing_control', 'Closing Control'),
        ('closed', 'Closed & Posted'),
    ]

    state = fields.Selection(
        POS_SESSION_STATE,
        string='Status',
        required=True,
        readonly=True,
        index=True,
        copy=False,
        default='opening_control'
    )

    def action_approve_review(self):
        for session in self:
            session.state = 'closing_control'




    def close_session_from_ui(self, bank_payment_method_diff_pairs):
        self.ensure_one()
        if self.state == 'closing_control':
            self.write({'state': 'to_review'})
            return {'successful': True}
        return {'successful': False, 'message': "Session is not ready to be reviewed."}
