/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";

patch(PosStore.prototype, {
    async closeSession() {
        if (!this.config.allow_closing_session) {
            this.dialog.add(AlertDialog, {
                title: _t("Permission Denied"),
                body: _t("Review will be required for you to  close the session."),
            });
            return;
        }
        return await super.closeSession();
    },
});
