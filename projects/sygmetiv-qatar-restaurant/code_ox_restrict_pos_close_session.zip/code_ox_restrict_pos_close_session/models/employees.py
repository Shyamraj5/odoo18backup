from odoo import fields, models, api


class Employees(models.Model):
    _inherit = "hr.employee"

    restrict_session_close = fields.Boolean(string="Restrict Session Close",)
    